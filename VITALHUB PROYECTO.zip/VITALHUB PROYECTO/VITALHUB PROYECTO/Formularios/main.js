function toggleMenu() {
    const menu = document.getElementById('dropdownMenu');
    // Alternar la visibilidad del menú
    if (menu.style.display === 'block') {
        menu.style.display = 'none';
    } else {
        menu.style.display = 'block';
    }
}

// Cierra el menú si se hace clic fuera de él
window.addEventListener('click', function(event) {
    const menu = document.getElementById('dropdownMenu');
    const profileIcon = document.querySelector('.profile-icon');
    if (!profileIcon.contains(event.target)) {
        menu.style.display = 'none';
    }
});