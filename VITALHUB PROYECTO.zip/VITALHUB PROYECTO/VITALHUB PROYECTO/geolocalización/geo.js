// Cargar el mapa con Leaflet
const map = L.map('map').setView([0, 0], 13); // Coordenadas iniciales (ajustadas después)

// Agregar el tile layer de OpenStreetMap
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
}).addTo(map);

// Geolocalización del usuario
if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
        position => {
            const userLat = position.coords.latitude;
            const userLng = position.coords.longitude;

            // Centramos el mapa en la ubicación del usuario
            map.setView([userLat, userLng], 15);

            // Añadimos un marcador en la ubicación del usuario
            L.marker([userLat, userLng]).addTo(map)
                .bindPopup('Tu ubicación actual')
                .openPopup();

            // Llamar a la función para buscar actividades cercanas
            buscarLugaresCercanos(userLat, userLng);
        },
        error => {
            alert('No se pudo obtener la ubicación. Por favor activa el GPS.');
        }
    );
} else {
    alert('La geolocalización no es compatible con este navegador.');
}

// Función para buscar actividades cercanas (usando un ejemplo de datos locales)
function buscarLugaresCercanos(lat, lng) {
    // Ejemplo de datos simulados de actividades cercanas
    const lugares = [
        { nombre: "Parque Central", lat: lat + 0.001, lng: lng - 0.001, tipo: "parque" },
        { nombre: "Gimnasio ProFit", lat: lat - 0.002, lng: lng + 0.003, tipo: "gimnasio" },
        { nombre: "Sendero del Bosque", lat: lat + 0.003, lng: lng - 0.002, tipo: "senderismo" }
    ];

    // Añadir marcadores de las actividades al mapa
    lugares.forEach(lugar => {
        L.marker([lugar.lat, lugar.lng]).addTo(map)
            .bindPopup(`${lugar.nombre} (${lugar.tipo})`);
    });
}



function toggleMenu() {
    const menu = document.getElementById('dropdownMenu');
    // Alternar la visibilidad del menú
    if (menu.style.display === 'block') {
        menu.style.display = 'none';
    } else {
        menu.style.display = 'block';
    }
}

// Cierra el menú si se hace clic fuera de él
window.addEventListener('click', function(event) {
    const menu = document.getElementById('dropdownMenu');
    const profileIcon = document.querySelector('.profile-icon');
    if (!profileIcon.contains(event.target)) {
        menu.style.display = 'none';
    }
});