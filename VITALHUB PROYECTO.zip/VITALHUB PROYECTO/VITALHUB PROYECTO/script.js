//Registro
function registerUser(event) {
    event.preventDefault(); // Evita el comportamiento predeterminado del formulario

    // Capturamos los valores del formulario
    const nombre = document.getElementById("nombre").value;
    const correo = document.getElementById("correo").value;
    const contrasena = document.getElementById("contrasena").value;

    // Validamos que todos los campos estén llenos
    if (nombre && correo && contrasena) {
        // Guardamos los datos en LocalStorage
        localStorage.setItem("nombre", nombre);
        localStorage.setItem("correo", correo);
        localStorage.setItem("contrasena", contrasena);

        alert("Cuenta creada exitosamente!");
        window.location.href = "../login/login.html"; // Redirección a la página de inicio de sesión
    } else {
        alert("Por favor, completa todos los campos.");
    }
}


// Iniciar sesión
function loginUser(event) {
    event.preventDefault(); // Evita el comportamiento predeterminado del formulario

    // Capturamos los valores del formulario
    const username = document.querySelector("input[name='username']").value;
    const password = document.querySelector("input[name='password']").value;

    // Recuperamos los datos almacenados en LocalStorage
    const storedCorreo = localStorage.getItem("correo"); // Correo registrado
    const storedPassword = localStorage.getItem("contrasena"); // Contraseña registrada

    // Validamos las credenciales
    if (username === storedCorreo && password === storedPassword) {
        alert("Inicio de sesión exitoso!");
        localStorage.setItem("isLoggedIn", true); // Indicador de sesión iniciada
        window.location.href = "../Mi Cuenta/MiCuenta.html"; // Redirección a la página principal
    } else {
        alert("Usuario o contraseña incorrectos.");
    }
}

// Cerrar sesión
function logout() {
    localStorage.removeItem("isLoggedIn");
    alert("Sesión cerrada.");
    window.location.href = "../login/login.html"; // Redirección ajustada
}
